#include <WiFi.h>
#include <HTTPClient.h>
#include <DHTesp.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <ArduinoJson.h>

const char* WIFI_SSID = "Wokwi-GUEST";
const char* WIFI_PASS = "";

const char* FIREBASE_URL = "https://wokwi2-6ba53-default-rtdb.asia-southeast1.firebasedatabase.app";

const int DHT_PIN = 15;

DHTesp dht;
LiquidCrystal_I2C lcd(0x27, 16, 2);

unsigned long previousMillis = 0;
const unsigned long interval = 5000;

void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;

  WiFi.begin(WIFI_SSID, WIFI_PASS);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi Connected");
  Serial.println(WiFi.localIP());
}

void kirimFirebase(float suhu, float kelembaban) {
  if (WiFi.status() != WL_CONNECTED) return;

  HTTPClient http;

  String url = String(FIREBASE_URL) + "/sensor.json";

  String json = "{";
  json += "\"suhu\":" + String(suhu, 1) + ",";
  json += "\"kelembaban\":" + String(kelembaban, 1);
  json += "}";

  http.begin(url);
  http.addHeader("Content-Type", "application/json");

  int code = http.PUT(json);

  Serial.print("PUT : ");
  Serial.println(code);

  http.end();
}

void bacaFirebase() {
  if (WiFi.status() != WL_CONNECTED) return;

  HTTPClient http;

  String url = String(FIREBASE_URL) + "/sensor.json";

  http.begin(url);

  int code = http.GET();

  if (code == HTTP_CODE_OK) {

    String payload = http.getString();

    JsonDocument doc;

    DeserializationError error = deserializeJson(doc, payload);

    if (!error) {

      float suhu = doc["suhu"];
      float hum = doc["kelembaban"];

      lcd.clear();

      lcd.setCursor(0, 0);
      lcd.print("Suhu :");
      lcd.print(suhu, 1);
      lcd.write(223);
      lcd.print("C");

      lcd.setCursor(0, 1);
      lcd.print("Hum  :");
      lcd.print(hum, 1);
      lcd.print("%");

      Serial.println(payload);
    }
  }

  http.end();
}

void setup() {

  Serial.begin(115200);

  dht.setup(DHT_PIN, DHTesp::DHT22);

  Wire.begin(21, 22);

  lcd.init();
  lcd.backlight();

  lcd.setCursor(0,0);
  lcd.print("Connecting");

  connectWiFi();

  lcd.clear();
  lcd.print("WiFi OK");

  delay(1000);
}

void loop() {

  if (millis() - previousMillis >= interval) {

    previousMillis = millis();

    TempAndHumidity data = dht.getTempAndHumidity();

    if (dht.getStatus() == 0) {

      Serial.print("Suhu : ");
      Serial.println(data.temperature);

      Serial.print("Hum  : ");
      Serial.println(data.humidity);

      kirimFirebase(data.temperature, data.humidity);

      delay(300);

      bacaFirebase();
    }
  }
}